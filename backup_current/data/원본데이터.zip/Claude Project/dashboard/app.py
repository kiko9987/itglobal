from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import os
import sys
import logging
from datetime import datetime, timedelta
import json
from dotenv import load_dotenv

# 프로젝트 루트 경로를 시스템 경로에 추가
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(project_root))

from dashboard.utils.google_sheets import GoogleSheetsManager
from dashboard.utils.data_analyzer import DataAnalyzer

# 환경 변수 로드
load_dotenv()

# Flask 앱 초기화
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('FLASK_SECRET_KEY', 'your-secret-key-here')

# SocketIO 초기화 (실시간 업데이트용)
socketio = SocketIO(app, cors_allowed_origins="*")

# 로깅 설정
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 전역 변수
current_data = None
last_update = None

def load_data():
    """구글 시트에서 데이터 로드"""
    global current_data, last_update
    
    try:
        sheet_id = os.getenv('GOOGLE_SHEET_ID')
        if not sheet_id:
            logger.error("GOOGLE_SHEET_ID가 설정되지 않았습니다.")
            return None
        
        # 구글 시트에서 데이터 가져오기
        manager = GoogleSheetsManager()
        df = manager.get_sheet_data(sheet_id)
        
        if df.empty:
            logger.warning("구글 시트에서 데이터를 가져올 수 없습니다.")
            return None
        
        current_data = df
        last_update = datetime.now()
        
        logger.info(f"데이터 로드 완료: {len(df)}행, 업데이트 시간: {last_update}")
        return df
        
    except Exception as e:
        logger.error(f"데이터 로드 오류: {str(e)}")
        
        # 로컬 엑셀 파일로 폴백
        try:
            import pandas as pd
            df = pd.read_excel('data/아이티 공사 현황.xlsx', sheet_name='공사 현황')
            current_data = df
            last_update = datetime.now()
            logger.info(f"로컬 파일에서 데이터 로드: {len(df)}행")
            return df
        except Exception as e2:
            logger.error(f"로컬 파일 로드도 실패: {str(e2)}")
            return None

@app.route('/')
def dashboard():
    """메인 대시보드 페이지"""
    return render_template('dashboard.html')

@app.route('/projects')
def project_list():
    """프로젝트 목록 페이지"""
    return render_template('project_list.html')

@app.route('/project/new')
def project_form_new():
    """새 프로젝트 등록 페이지"""
    return render_template('project_form.html')

@app.route('/project/edit')
def project_form_edit():
    """프로젝트 수정 페이지"""
    return render_template('project_form.html')

@app.route('/api/summary')
def get_summary():
    """요약 통계 API"""
    try:
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        analyzer = DataAnalyzer(df)
        summary = analyzer.get_summary_stats()
        
        # 추가 정보
        summary['last_update'] = last_update.isoformat() if last_update else None
        summary['total_records'] = len(df)
        
        return jsonify(summary)
        
    except Exception as e:
        logger.error(f"요약 통계 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/monthly-sales')
def get_monthly_sales():
    """월별 매출 API"""
    try:
        year = request.args.get('year', datetime.now().year, type=int)
        
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        analyzer = DataAnalyzer(df)
        monthly_sales = analyzer.get_monthly_sales(year)
        
        # JSON 직렬화 가능한 형태로 변환
        result = monthly_sales.to_dict('records') if not monthly_sales.empty else []
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"월별 매출 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/regional-analysis')
def get_regional_analysis():
    """지역별 분석 API"""
    try:
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        analyzer = DataAnalyzer(df)
        regional = analyzer.get_regional_analysis()
        
        result = regional.to_dict('records') if not regional.empty else []
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"지역별 분석 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/outstanding-analysis')
def get_outstanding_analysis():
    """미수금 분석 API"""
    try:
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        analyzer = DataAnalyzer(df)
        outstanding = analyzer.get_outstanding_analysis()
        
        # DataFrame을 dict로 변환
        result = {}
        for key, value in outstanding.items():
            if hasattr(value, 'to_dict'):
                result[key] = value.to_dict('records')
            else:
                result[key] = value
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"미수금 분석 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/missing-data')
def get_missing_data():
    """누락 데이터 분석 API"""
    try:
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        analyzer = DataAnalyzer(df)
        missing = analyzer.check_missing_data()
        
        # DataFrame을 dict로 변환 (JSON 직렬화 가능하도록)
        import json
        result = {}
        for key, value in missing.items():
            if hasattr(value, 'to_dict'):
                result[key] = value.to_dict('records')
            elif isinstance(value, dict):
                # dict 내부의 numpy 타입들을 Python 기본 타입으로 변환
                converted_dict = {}
                for k, v in value.items():
                    if hasattr(v, 'item'):  # numpy 타입인 경우
                        converted_dict[k] = v.item()
                    elif hasattr(v, 'tolist'):  # numpy 배열인 경우
                        converted_dict[k] = v.tolist()
                    else:
                        converted_dict[k] = v
                result[key] = converted_dict
            else:
                # numpy 타입을 Python 기본 타입으로 변환
                if hasattr(value, 'item'):
                    result[key] = value.item()
                elif hasattr(value, 'tolist'):
                    result[key] = value.tolist()
                else:
                    result[key] = value
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"누락 데이터 분석 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/brand-analysis')
def get_brand_analysis():
    """브랜드별 분석 API"""
    try:
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        analyzer = DataAnalyzer(df)
        brands = analyzer.get_brand_analysis()
        
        result = brands.to_dict('records') if not brands.empty else []
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"브랜드별 분석 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/refresh-data')
def refresh_data():
    """데이터 새로고침 API"""
    try:
        df = load_data()
        if df is None:
            return jsonify({'error': '데이터 새로고침 실패'}), 500
        
        # 실시간 업데이트 알림
        socketio.emit('data_updated', {
            'message': '데이터가 업데이트되었습니다.',
            'timestamp': last_update.isoformat() if last_update else None,
            'record_count': len(df)
        })
        
        return jsonify({
            'message': '데이터 새로고침 완료',
            'timestamp': last_update.isoformat() if last_update else None,
            'record_count': len(df)
        })
        
    except Exception as e:
        logger.error(f"데이터 새로고침 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@socketio.on('connect')
def handle_connect():
    """클라이언트 연결 처리"""
    logger.info('클라이언트가 연결되었습니다.')
    emit('connected', {'message': '대시보드에 연결되었습니다.'})

@socketio.on('disconnect')
def handle_disconnect():
    """클라이언트 연결 해제 처리"""
    logger.info('클라이언트 연결이 해제되었습니다.')

@app.route('/api/projects/list')
def get_projects_list():
    """프로젝트 목록 API"""
    try:
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        # DataFrame을 dict 리스트로 변환 (NaN 값 처리)
        df = df.fillna('')  # NaN 값을 빈 문자열로 변환
        
        # 날짜 컬럼들을 문자열로 변환
        date_columns = ['공사 시작', '공사 종료', '수금 날짜', '공사 확정']
        for col in date_columns:
            if col in df.columns:
                df[col] = df[col].astype(str).replace('NaT', '').replace('nan', '')
        
        projects = df.to_dict('records')
        
        return jsonify(projects)
        
    except Exception as e:
        logger.error(f"프로젝트 목록 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/next-project-code')
def get_next_project_code():
    """다음 프로젝트 코드 생성 API"""
    try:
        region_code = request.args.get('region', 'IT')
        
        sheet_id = os.getenv('GOOGLE_SHEET_ID')
        if not sheet_id:
            return jsonify({'error': 'GOOGLE_SHEET_ID가 설정되지 않았습니다.'}), 500
        
        manager = GoogleSheetsManager()
        project_code = manager.get_next_project_code(sheet_id, region_code)
        
        return jsonify({'project_code': project_code})
        
    except Exception as e:
        logger.error(f"프로젝트 코드 생성 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/projects', methods=['POST'])
def create_project():
    """새 프로젝트 생성 API"""
    try:
        data = request.get_json()
        
        sheet_id = os.getenv('GOOGLE_SHEET_ID')
        if not sheet_id:
            return jsonify({'error': 'GOOGLE_SHEET_ID가 설정되지 않았습니다.'}), 500
        
        manager = GoogleSheetsManager()
        
        # 데이터를 구글 시트 형식으로 변환
        values = convert_form_data_to_sheet_row(data, manager)
        
        # 구글 시트에 추가
        result = manager.append_row(sheet_id, values)
        
        # 로컬 데이터 새로고침
        load_data()
        
        # 실시간 업데이트 알림
        socketio.emit('data_updated', {
            'message': f"새 프로젝트가 등록되었습니다: {data.get('projectCode', '')}",
            'timestamp': datetime.now().isoformat(),
            'action': 'create'
        })
        
        return jsonify({'success': True, 'project_code': data.get('projectCode', '')})
        
    except Exception as e:
        logger.error(f"프로젝트 생성 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/projects/<project_code>', methods=['GET'])
def get_project(project_code):
    """프로젝트 상세 정보 API"""
    try:
        df = current_data if current_data is not None else load_data()
        if df is None:
            return jsonify({'error': '데이터를 불러올 수 없습니다.'}), 500
        
        # 프로젝트 코드로 찾기
        project_row = df[df['프로젝트 코드'] == project_code]
        
        if project_row.empty:
            return jsonify({'error': '프로젝트를 찾을 수 없습니다.'}), 404
        
        project = project_row.iloc[0].to_dict()
        
        return jsonify(project)
        
    except Exception as e:
        logger.error(f"프로젝트 조회 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/projects/<project_code>', methods=['PUT'])
def update_project(project_code):
    """프로젝트 수정 API"""
    try:
        data = request.get_json()
        
        sheet_id = os.getenv('GOOGLE_SHEET_ID')
        if not sheet_id:
            return jsonify({'error': 'GOOGLE_SHEET_ID가 설정되지 않았습니다.'}), 500
        
        manager = GoogleSheetsManager()
        
        # 프로젝트가 있는 행 찾기
        row_number = manager.find_row_by_project_code(sheet_id, project_code)
        
        if not row_number:
            return jsonify({'error': '프로젝트를 찾을 수 없습니다.'}), 404
        
        # 데이터를 구글 시트 형식으로 변환
        values = convert_form_data_to_sheet_row(data, manager)
        
        # 구글 시트 업데이트
        result = manager.update_row(sheet_id, row_number, values)
        
        # 로컬 데이터 새로고침
        load_data()
        
        # 실시간 업데이트 알림
        socketio.emit('data_updated', {
            'message': f"프로젝트가 수정되었습니다: {project_code}",
            'timestamp': datetime.now().isoformat(),
            'action': 'update'
        })
        
        return jsonify({'success': True, 'project_code': project_code})
        
    except Exception as e:
        logger.error(f"프로젝트 수정 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/projects/<project_code>', methods=['DELETE'])
def delete_project(project_code):
    """프로젝트 삭제 API (구글 시트에서는 빈 행으로 만들기)"""
    try:
        sheet_id = os.getenv('GOOGLE_SHEET_ID')
        if not sheet_id:
            return jsonify({'error': 'GOOGLE_SHEET_ID가 설정되지 않았습니다.'}), 500
        
        manager = GoogleSheetsManager()
        
        # 프로젝트가 있는 행 찾기
        row_number = manager.find_row_by_project_code(sheet_id, project_code)
        
        if not row_number:
            return jsonify({'error': '프로젝트를 찾을 수 없습니다.'}), 404
        
        # 빈 값들로 행 업데이트 (삭제 대신)
        empty_values = [''] * 39  # 39개 컬럼
        result = manager.update_row(sheet_id, row_number, empty_values)
        
        # 로컬 데이터 새로고침
        load_data()
        
        # 실시간 업데이트 알림
        socketio.emit('data_updated', {
            'message': f"프로젝트가 삭제되었습니다: {project_code}",
            'timestamp': datetime.now().isoformat(),
            'action': 'delete'
        })
        
        return jsonify({'success': True})
        
    except Exception as e:
        logger.error(f"프로젝트 삭제 API 오류: {str(e)}")
        return jsonify({'error': str(e)}), 500

def convert_form_data_to_sheet_row(form_data, manager):
    """폼 데이터를 구글 시트 행 형식으로 변환"""
    column_mapping = manager.get_column_mapping()
    
    # 폼 필드명을 구글 시트 컬럼명으로 매핑
    field_mapping = {
        'projectCode': '프로젝트 코드',
        'company': '사업자',
        'region': '담당자',
        'client': '거래처',
        'address': '현장 주소',
        'workType': '공사 구분',
        'equipmentType': '기계 분류',
        'brand': '브랜드',
        'startDate': '공사 시작',
        'endDate': '공사 종료',
        'workDescription': '공사 내용',
        'contractType': '도급 구분',
        'constructor': '시공자',
        'siteManager': '현장 담당자',
        'managerPhone': '담당자 연락처',
        'managerEmail': '담당자 이메일',
        'amount1': '총액 1',
        'vatIncluded': '부가세',
        'amount2': '총액 2',
        'downPayment': '계약금',
        'middlePayment': '중도금',
        'finalPayment': '잔금',
        'outstanding': '미수금',
        'invoice': '계산서',
        'paymentDate': '수금 날짜',
        'paymentConfirmed': '수금 확인',
        'productCost': '제품대',
        'laborCost': '도급비',
        'materialCost': '자재비',
        'otherCost': '기타비',
        'netProfit': '순익',
        'marginRate': '마진율',
        'notes': '비고',
        'downPaymentPayer': '계약금 입금자명',
        'middlePaymentPayer': '중도금 입금자명',
        'finalPaymentPayer': '잔금 입금자명'
    }
    
    # 39개 컬럼에 맞춰 빈 리스트 생성
    values = [''] * 39
    
    # 각 컬럼에 해당하는 값 설정
    for column_letter, column_name in column_mapping.items():
        column_index = ord(column_letter) - ord('A') if len(column_letter) == 1 else \
                      (ord(column_letter[0]) - ord('A') + 1) * 26 + (ord(column_letter[1]) - ord('A'))
        
        # 폼 데이터에서 해당 값 찾기
        form_field = None
        for form_key, sheet_column in field_mapping.items():
            if sheet_column == column_name:
                form_field = form_key
                break
        
        if form_field and form_field in form_data:
            value = form_data[form_field]
            
            # 데이터 타입별 처리
            if isinstance(value, bool):
                values[column_index] = 'TRUE' if value else 'FALSE'
            elif isinstance(value, (int, float)):
                values[column_index] = str(value) if value != 0 else ''
            else:
                values[column_index] = str(value) if value else ''
    
    return values

@socketio.on('connect')
def handle_connect():
    """클라이언트 연결 처리"""
    logger.info('클라이언트가 연결되었습니다.')
    emit('connected', {'message': '대시보드에 연결되었습니다.'})

@socketio.on('disconnect')
def handle_disconnect():
    """클라이언트 연결 해제 처리"""
    logger.info('클라이언트 연결이 해제되었습니다.')

@socketio.on('request_update')
def handle_request_update():
    """실시간 업데이트 요청 처리"""
    try:
        df = load_data()
        if df is not None:
            emit('data_updated', {
                'message': '데이터가 업데이트되었습니다.',
                'timestamp': last_update.isoformat() if last_update else None,
                'record_count': len(df)
            })
    except Exception as e:
        emit('error', {'message': f'업데이트 오류: {str(e)}'})

if __name__ == '__main__':
    # 초기 데이터 로드
    logger.info("초기 데이터 로드 중...")
    load_data()
    
    # 서버 시작
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('DEBUG', 'True').lower() == 'true'
    
    logger.info(f"대시보드 서버 시작: http://localhost:{port}")
    socketio.run(app, debug=debug, host='0.0.0.0', port=port)