import logging
from typing import Dict, List, Optional
import pandas as pd
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

logger = logging.getLogger(__name__)

class GoogleSheetsManager:
    SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

    def __init__(self, sheet_id: str, range_a1: str, service_account_json: str):
        self.sheet_id = sheet_id
        self.range_a1 = range_a1
        self.service_account_json = service_account_json
        self._service = self._build_service()
        self._headers: List[str] = []
        self._last_df: Optional[pd.DataFrame] = None

    def _build_service(self):
        creds = Credentials.from_service_account_file(
            self.service_account_json, scopes=self.SCOPES
        )
        return build("sheets", "v4", credentials=creds, cache_discovery=False)

    def fetch_dataframe(self) -> pd.DataFrame:
        values = self._service.spreadsheets().values().get(
            spreadsheetId=self.sheet_id, range=self.range_a1
        ).execute().get("values", [])

        if not values:
            return pd.DataFrame()

        self._headers = values[0]
        rows = values[1:]
        df = pd.DataFrame(rows, columns=self._headers).fillna("").replace({None: ""})
        self._last_df = df
        return df

    def append_row(self, record: Dict[str, str]) -> None:
        if not self._headers:
            self.fetch_dataframe()
        row = [record.get(h, "") for h in self._headers]
        self._service.spreadsheets().values().append(
            spreadsheetId=self.sheet_id,
            range=self.range_a1.split("!")[0],
            valueInputOption="USER_ENTERED",
            insertDataOption="INSERT_ROWS",
            body={"values": [row]},
        ).execute()
