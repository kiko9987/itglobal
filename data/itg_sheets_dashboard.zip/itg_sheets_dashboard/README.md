# ITG Sheets Dashboard (Flask + Socket.IO)

구글 시트를 **실시간**으로 연동하는 내부 대시보드입니다.
- 역할/권한: 담당자 본인은 본인 행만 보기, 관리자 화이트리스트는 전체 보기
- 실시간: 10초 폴링 → 변경 감지 시 Socket.IO로 클라이언트별 필터링 전송
- API: 목록/추가/수정 (서버 단 필터 적용)
- 알림: 누락 필드, 공사확정 후 계약금 미입금 지연 → Slack Webhook 알림
- 안전: 서비스계정 키는 .git에 올리지 말고 `.env`에서 경로만 지정하세요

## 빠른 시작

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env   # 환경 변수 채우기
# Google 서비스계정 키 json 파일 준비 후 .env에 경로 입력
python dashboard/app.py
```

- 브라우저에서 `http://localhost:5000` 접속
- 인증: 간단한 API Key + 사용자 이메일 헤더로 처리
  - `X-API-Key: <.env의 API_KEY>`
  - `X-User-Email: user@example.com`

## 시트 전제
- 첫 행은 **헤더**입니다. (예: `프로젝트 코드`, `담당자 이메일`, `현장 주소`, `공사 확정`, `등록일`, `계약금 입금일` 등)
- 열의 순서는 바뀌어도 헤더명으로 매핑합니다.

## 주요 컬럼(권장)
- 프로젝트 코드 (고유값)
- 담당자 이메일
- 현장 주소
- 공사 확정 (TRUE/YES/예 등)
- 등록일 (YYYY-MM-DD)
- 계약금 입금일 (YYYY-MM-DD)

## 알림 규칙(기본값)
- 누락 필드: `.env`의 `REQUIRED_FIELDS`에서 지정, 하나라도 비면 담당자/관리자에 Slack DM/채널로 알림
- 공사 확정 후 계약금 미입금: `공사 확정=TRUE` 이고 `계약금 입금일`이 비어 있으며 `등록일`이 `OVERDUE_CONFIRM_DAYS`일 초과

중복 알림 방지: `NOTIFY_SUPPRESS_MINUTES` 안에 같은 건은 중복 발송 안 함(메모리 기준).

## 보안 주의
- 서비스계정 키 JSON은 깃에 올리지 말 것
- 가능하다면 Secret Manager 사용
