(function(){
  // 간단한 데모: 로컬 스토리지에 사용자/키를 저장
  const apiKey = localStorage.getItem('apiKey') || prompt('API Key (.env의 API_KEY)?');
  const userEmail = localStorage.getItem('userEmail') || prompt('당신의 이메일?');
  localStorage.setItem('apiKey', apiKey);
  localStorage.setItem('userEmail', userEmail);
  document.getElementById('who').textContent = userEmail;

  const thead = document.getElementById('thead');
  const tbody = document.getElementById('tbody');
  const monthEl = document.getElementById('month');
  const managerEl = document.getElementById('manager');
  const mineEl = document.getElementById('mine');

  function render(rows){
    tbody.innerHTML='';
    if(!rows || rows.length===0){ tbody.innerHTML = '<tr><td class="muted">데이터 없음</td></tr>'; return; }
    const cols = Object.keys(rows[0]);
    thead.innerHTML = '<tr>'+cols.map(c=>`<th>${c}</th>`).join('')+'</tr>';
    rows.forEach(r=>{
      const tr = document.createElement('tr');
      tr.innerHTML = cols.map(c=>`<td>${(r[c]||'').toString()}</td>`).join('');
      tbody.appendChild(tr);
    });
  }

  const socket = io({extraHeaders:{'X-API-Key': apiKey, 'X-User-Email': userEmail}});

  socket.on('connect', ()=>{
    socket.emit('auth', {apiKey, userEmail});
    socket.emit('projects:subscribe', {filters: {}});
  });

  socket.on('projects:update', payload=>{ render(payload.rows); });

  document.getElementById('refresh').addEventListener('click', async ()=>{
    const month = monthEl.value.trim();
    const manager = managerEl.value.trim();
    const mine = mineEl.value.trim();
    const url = new URL(location.origin + '/api/projects');
    if(month) url.searchParams.set('month', month);
    if(manager) url.searchParams.set('manager', manager);
    if(mine) url.searchParams.set('mine', '1');
    const resp = await fetch(url.toString(), {headers:{'X-API-Key': apiKey, 'X-User-Email': userEmail}});
    const data = await resp.json();
    render(data.rows || []);
  });
})();