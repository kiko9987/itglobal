import os
import logging
from typing import Dict, List, Optional
import pandas as pd
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

logger = logging.getLogger(__name__)

class GoogleSheetsManager:
    SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]

    def __init__(self, sheet_id: str, range_a1: str, service_account_json: str):
        self.sheet_id = sheet_id
        self.range_a1 = range_a1
        self.service_account_json = service_account_json
        self._service = self._build_service()
        self._headers: List[str] = []
        self._last_df: Optional[pd.DataFrame] = None

    def _build_service(self):
        creds = Credentials.from_service_account_file(
            self.service_account_json, scopes=self.SCOPES
        )
        return build("sheets", "v4", credentials=creds, cache_discovery=False)

    def fetch_dataframe(self) -> pd.DataFrame:
        values = self._service.spreadsheets().values().get(
            spreadsheetId=self.sheet_id, range=self.range_a1
        ).execute().get("values", [])

        if not values:
            return pd.DataFrame()

        self._headers = values[0]
        rows = values[1:]
        df = pd.DataFrame(rows, columns=self._headers)
        df = df.fillna("").replace({None: ""})
        self._last_df = df
        return df

    def append_row(self, record: Dict[str, str]) -> None:
        if not self._headers:
            self.fetch_dataframe()
        row = [record.get(h, "") for h in self._headers]
        self._service.spreadsheets().values().append(
            spreadsheetId=self.sheet_id,
            range=self.range_a1.split("!")[0],
            valueInputOption="USER_ENTERED",
            insertDataOption="INSERT_ROWS",
            body={"values": [row]},
        ).execute()

    def find_row_index(self, key_col: str, key_value: str) -> Optional[int]:
        df = self._last_df if self._last_df is not None else self.fetch_dataframe()
        if key_col not in df.columns:
            return None
        hits = df.index[df[key_col] == key_value].tolist()
        return hits[0] if hits else None

    def update_row(self, row_idx: int, patch: Dict[str, str]) -> None:
        if not self._headers:
            self.fetch_dataframe()
        df = self._last_df if self._last_df is not None else self.fetch_dataframe()
        if row_idx < 0 or row_idx >= len(df):
            raise IndexError("row_idx out of range")

        for k, v in patch.items():
            if k in df.columns:
                df.at[row_idx, k] = v

        new_row = [df.at[row_idx, h] if h in df.columns else "" for h in self._headers]
        # 실제 행 번호 (헤더 1행)
        target_row_number = row_idx + 2
        sheet_name = self.range_a1.split("!")[0]
        update_range = f"{sheet_name}!A{target_row_number}:{self._col_letter(len(self._headers))}{target_row_number}"

        self._service.spreadsheets().values().update(
            spreadsheetId=self.sheet_id,
            range=update_range,
            valueInputOption="USER_ENTERED",
            body={"values": [new_row]},
        ).execute()

    @staticmethod
    def _col_letter(n: int) -> str:
        s = ""
        while n > 0:
            n, r = divmod(n-1, 26)
            s = chr(65 + r) + s
        return s
