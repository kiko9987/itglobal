import os
from typing import Tuple

API_KEY = os.getenv("API_KEY", "").strip()
ADMIN_EMAILS = [x.strip().lower() for x in os.getenv("ADMIN_EMAILS", "").split(",") if x.strip()]

def check_api_key(key: str) -> bool:
    return API_KEY and key == API_KEY

def is_admin(email: str) -> bool:
    return email.lower() in ADMIN_EMAILS

def get_user_from_headers(headers) -> Tuple[str, bool]:
    api_key = headers.get("X-API-Key")
    user_email = headers.get("X-User-Email", "").strip()
    ok = check_api_key(api_key)
    admin = is_admin(user_email) if user_email else False
    return (user_email, admin) if ok else ("", False)
