import os
import time
import logging
from typing import List, Dict, Tuple
import requests

logger = logging.getLogger(__name__)

class NotificationSystem:
    def __init__(self):
        self.slack_webhook = os.getenv("SLACK_WEBHOOK_URL", "").strip()
        self.suppress_minutes = int(os.getenv("NOTIFY_SUPPRESS_MINUTES", "120"))
        self._recent: Dict[str, float] = {}  # key -> last_ts

    def _should_send(self, key: str) -> bool:
        now = time.time()
        last = self._recent.get(key, 0)
        if now - last >= self.suppress_minutes * 60:
            self._recent[key] = now
            return True
        return False

    def _post_slack(self, text: str):
        if not self.slack_webhook:
            logger.info(f"[SLACK DRYRUN] {text}")
            return True
        try:
            resp = requests.post(self.slack_webhook, json={"text": text}, timeout=10)
            if resp.status_code // 100 == 2:
                return True
            logger.error(f"Slack error {resp.status_code}: {resp.text}")
        except Exception as e:
            logger.exception(f"Slack post failed: {e}")
        return False

    def notify_missing_fields(self, items: List[Dict]):
        for it in items:
            proj = it.get("프로젝트 코드") or it.get("project_code") or "(미지정)"
            missing = ", ".join(it.get("_missing_fields", []))
            owner = it.get("담당자 이메일", "")
            key = f"missing:{proj}:{missing}"
            if self._should_send(key):
                text = f"⚠️ 누락 필드 감지
• 프로젝트: {proj}
• 누락: {missing}
• 담당자: {owner}"
                self._post_slack(text)

    def notify_overdue_deposit(self, items: List[Dict]):
        for it in items:
            proj = it.get("프로젝트 코드") or "(미지정)"
            owner = it.get("담당자 이메일", "")
            days = it.get("_overdue_days", "?")
            key = f"overdue:{proj}:{days}"
            if self._should_send(key):
                text = f"⏰ 계약금 미입금 지연
• 프로젝트: {proj}
• 담당자: {owner}
• 지연일: {days}일"
                self._post_slack(text)
